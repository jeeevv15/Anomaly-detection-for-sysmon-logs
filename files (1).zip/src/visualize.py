import pandas as pd
import matplotlib.pyplot as plt
import sys

def plot_event_distribution(input_path):
    df = pd.read_csv(input_path)
    df['EventID'].value_counts().sort_index().plot(kind='bar')
    plt.xlabel('EventID')
    plt.ylabel('Count')
    plt.title('Sysmon Event Type Distribution')
    plt.show()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python visualize.py <processed_csv>")
    else:
        plot_event_distribution(sys.argv[1])