import pandas as pd
import argparse
from sklearn.ensemble import IsolationForest

def run_anomaly_detection(input_path, output_path):
    df = pd.read_csv(input_path)
    # Simple feature: event count per process
    event_counts = df['Image'].value_counts()
    df['EventCount'] = df['Image'].map(event_counts)
    features = df[['EventCount']]  # Expand with more features for better results

    model = IsolationForest(contamination=0.01, random_state=42)
    df['anomaly'] = model.fit_predict(features)
    anomalies = df[df['anomaly'] == -1]
    anomalies.to_csv(output_path, index=False)
    print(f"Anomalies saved to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Detect anomalies in Sysmon logs.")
    parser.add_argument("--input", type=str, required=True, help="Path to processed Sysmon CSV log")
    parser.add_argument("--output", type=str, required=True, help="Path to save anomalies CSV")
    args = parser.parse_args()
    run_anomaly_detection(args.input, args.output)