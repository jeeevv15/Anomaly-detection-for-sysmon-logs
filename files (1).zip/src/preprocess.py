import pandas as pd
import argparse

def preprocess(input_path, output_path):
    df = pd.read_csv(input_path)
    # Example: Keep only relevant columns
    keep_cols = ["UtcTime", "EventID", "Image", "ParentImage", "CommandLine", "User", "DestinationIp", "SourceIp"]
    df = df[[col for col in keep_cols if col in df.columns]]
    # Fill missing values
    df = df.fillna("")
    df.to_csv(output_path, index=False)
    print(f"Processed data saved to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Preprocess Sysmon CSV logs.")
    parser.add_argument("--input", type=str, required=True, help="Path to raw Sysmon CSV log")
    parser.add_argument("--output", type=str, required=True, help="Path to save processed CSV")
    args = parser.parse_args()
    preprocess(args.input, args.output)