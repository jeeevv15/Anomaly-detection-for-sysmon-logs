# Optional: entry point for the project. Can be expanded as needed.
print("Welcome to Anomaly Detection in Sysmon Logs")
print("Use the scripts in src/ for preprocessing, detection, and visualization.")